//
//  LoginViewController.h
//  CoolRun
//
//  Created by 蔡欣东 on 16/5/24.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  登陆界面
 */
@interface LoginViewController : XDBaseViewController

@end
