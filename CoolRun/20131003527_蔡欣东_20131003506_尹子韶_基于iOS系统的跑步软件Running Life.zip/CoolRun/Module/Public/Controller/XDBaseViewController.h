//
//  XDBaseViewController.h
//  CoolRun
//
//  Created by 蔡欣东 on 2016/9/5.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDBaseViewController : UIViewController

- (void)KVOHandler;

- (void)configureView;

@end
