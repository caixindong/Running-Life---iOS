//
//  RunningBoardViewModel.m
//  CoolRun
//
//  Created by 蔡欣东 on 2016/9/5.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import "RunningBoardViewModel.h"

@implementation RunningBoardViewModel

@end
