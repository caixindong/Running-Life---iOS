//
//  RunningMapViewModel.m
//  CoolRun
//
//  Created by 蔡欣东 on 2016/9/8.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import "RunningMapViewModel.h"

@implementation RunningMapViewModel

@end
