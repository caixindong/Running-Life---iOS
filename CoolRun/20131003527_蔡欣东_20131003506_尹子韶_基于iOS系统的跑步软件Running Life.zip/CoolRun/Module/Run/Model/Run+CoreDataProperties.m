//
//  Run+CoreDataProperties.m
//  CoolRun
//
//  Created by 蔡欣东 on 16/5/27.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Run+CoreDataProperties.h"

@implementation Run (CoreDataProperties)

@dynamic distance;
@dynamic duration;
@dynamic timestamp;
@dynamic flag;
@dynamic runid;
@dynamic locations;

@end
