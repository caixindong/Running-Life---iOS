//
//  MultiColorPolyline.m
//  CoolRun
//
//  Created by 蔡欣东 on 16/5/20.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import "MultiColorPolyline.h"

@implementation MultiColorPolyline

@end
