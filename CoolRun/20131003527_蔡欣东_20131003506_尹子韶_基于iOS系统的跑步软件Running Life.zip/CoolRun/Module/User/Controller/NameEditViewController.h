//
//  NameEditViewController.h
//  CoolRun
//
//  Created by 蔡欣东 on 16/5/26.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserSettingViewModel.h"

@interface NameEditViewController : XDBaseViewController

@property(nonatomic, strong, readwrite)UserSettingViewModel *viewModel;

@end
