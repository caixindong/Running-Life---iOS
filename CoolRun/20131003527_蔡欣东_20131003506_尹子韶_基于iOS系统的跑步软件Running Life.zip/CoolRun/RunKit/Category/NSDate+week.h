//
//  NSDate+week.h
//  CoolRun
//
//  Created by 蔡欣东 on 16/6/4.
//  Copyright © 2016年 蔡欣东. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (week)

- (NSString *)convertToStringWithWeek;

@end
